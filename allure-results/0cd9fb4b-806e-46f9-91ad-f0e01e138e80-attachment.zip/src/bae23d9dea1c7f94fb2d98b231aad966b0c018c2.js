import { expect, test } from "@playwright/test";

test('Get Users', async ({ request }) => {
    const response = await request.get('https://reqres.in/api/users/2');
    console.log(await response.json());
    expect(response.status()).toBe(200);
})


test('Create User', async ( { request }) => {
    const response = await request.post('https://reqres.in/api/users', {
        data: {
            name: 'Smita QA',
            job: 'Software Engineer'
        },

        headers : {
            'Accept': 'application/json'
        }
    });
    console.log(await response.json());
    expect(response.status()).toBe(201);
})

test.only('Update User' , async ( { request }) => {

    await request.put('https://reqres.in/api/users/2', {
        data: {
            name: 'Smita QA',
            job: 'Senior Software Engineer'
        },
        headers: {
            'Accept': 'application/json'
        }
    });

     console.log(await response.json());
    expect(response.status()).toBe(200);
})