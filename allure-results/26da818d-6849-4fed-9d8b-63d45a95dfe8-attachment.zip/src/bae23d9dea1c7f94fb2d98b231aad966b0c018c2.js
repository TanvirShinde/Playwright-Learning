import { expect, test } from "@playwright/test";

test('Get Users', async ({ request }) => {
    const response = await request.get('https://reqres.in/api/users/2');
    console.log(await response.json());
    expect(response.status()).toBe(200);
})


test.only('Create User', async ( { request }) => {
    const response = await request.post('https://reqres.in/api/users', {
        data: {
            name: 'Tanvir QA',
            job: 'Software Engineer'
        }
    });
    console.log(await response.json());
    expect(response.status()).toBe(201);
})